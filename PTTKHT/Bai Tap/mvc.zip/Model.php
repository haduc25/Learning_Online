<?php


class Model
{
    public function getNews()
    {
        $news = [
            'tin 1',
            'tin 2',
            'tin 3',
            'tin 4',
        ];

        return $news;
    }

}