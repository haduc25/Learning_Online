<?php


class View
{
    public function indexNews($news)
    {
        include "pages/indexNews.php";
    }

}