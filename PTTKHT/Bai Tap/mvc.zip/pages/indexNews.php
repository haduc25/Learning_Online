<html>
<body>
<table border="1">
    <?php foreach($news as $n) :?>
    <tr>
        <td><?php echo $n;?></td>
    </tr>
    <?php endforeach; ?>
</table>
</body>
</html>
