<html>
<body>
<?php include "Templates/thongbao.php" ?>
<?php include "Templates/menu.php" ?>

    <table border="1">
        <tr>
            <td>id</td>
            <td>title</td>
            <td>content</td>
        </tr>
        <?php foreach($results  as $row) :?>
        <tr>
            <td><?php echo $row['id'] ?></td>
            <td><?php echo $row['title'] ?></td>
            <td><?php echo $row['content'] ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
