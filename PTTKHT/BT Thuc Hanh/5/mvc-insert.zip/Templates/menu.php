<ul>
    <li><a href="?task=getNews">Xem Tin</a></li>
    <li><a href="?task=createNews">Tao Tin moi</a></li>
</ul>
