<?php

class Model
{
    var $con;

    /**
     * Model constructor.
     */
    public function __construct()
    {
        $con = mysqli_connect("localhost", "root", "root", "news");
    }

    public function getNews()
    {
        $sql = "SELECT * from news";
        $rs = $this->con->query($sql);
        $results = [];
        while ($row = $rs->fetch_assoc()) {
            $results[] = $row;
        }

        return $results;
    }

    public function storeNews($form)
    {
        $sql = "INSERT INTO news(title,content) VALUES('".$form['title']."','".$form['content']."')";
        $rs = $this->con->query($sql);
        if($rs != true){
            var_dump($this->con->error);exit;
        }
        return $rs;
    }
}