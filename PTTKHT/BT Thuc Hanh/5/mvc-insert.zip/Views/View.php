<?php
class View
{

    /**
     * View constructor.
     */
    public function __construct()
    {
    }

    public function indexNews($results,$n)
    {
        include "Templates/pageIndex.php";
    }

    public function renderFormNews()
    {
        include  "Templates/formNews.php";
    }
}