<?php
require_once "Models\Model.php";
require_once "Views\View.php";

class Controller
{
    var $model;
    var $view;

    /**
     * Controller constructor.
     */
    public function __construct()
    {
        $this->model = new Model();
        $this->view = new View();
    }

    public function getNews()
    {
        $n = @$_REQUEST['n'];
        $results = $this->model->getNews();
        $this->view->indexNews($results,$n);
    }

    public function createNews()
    {
        $this->view->renderFormNews();
        
    }

    public function storeNews()
    {
        $form = [];
        $form['title'] = $_REQUEST['title'];
        $form['content'] = $_REQUEST['content'];
        $rs = $this->model->storeNews($form);
        if($rs == true){
            header('Location: ?task=getNews&n=thanhcong');
        }else{
            header('Location: ?task=getNews&n=khongthanhcong');
        }
    }
}