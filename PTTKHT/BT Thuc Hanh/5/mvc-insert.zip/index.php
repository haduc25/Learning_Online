<?php
require_once "Controllers/Controller.php";
$task = $_REQUEST['task'];
$con = new Controller();
$con->$task();
