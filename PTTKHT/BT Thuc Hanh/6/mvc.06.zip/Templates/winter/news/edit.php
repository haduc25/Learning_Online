<?php include "Templates/winter/partials/thongbao.php" ?>
<?php include "Templates/winter/partials/menu.php" ?>
edit form:
<form action="index.php?task=saveNews" method="POST" >
    title:
    <input type="text" name="title" id="title" value="<?php echo $row['title'] ?>" />
    <br />
    Content
    <input type="text" name="content" id="content" value="<?php echo $row['content'] ?>" />
    <input type="hidden" name="id" value="<?php echo $row['id'] ?>" />
    <input type="submit" value="luu tin">
</form>
