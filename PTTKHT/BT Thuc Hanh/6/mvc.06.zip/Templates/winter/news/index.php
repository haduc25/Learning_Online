<html>
<body>
<?php include "Templates/winter/partials/thongbao.php" ?>
<?php include "Templates/winter/partials/menu.php" ?>

    <table border="1">
        <tr>
            <td>id</td>
            <td>title</td>
            <td>content</td>
            <td>tools</td>
        </tr>
        <?php foreach($results  as $row) :?>
        <tr>
            <td><?php echo $row['id'] ?></td>
            <td><?php echo $row['title'] ?></td>
            <td><?php echo $row['content'] ?></td>
            <td>
                <a href="?task=deleteNews&id=<?php echo $row['id'] ?>">delete</a>
                <a href="?task=updateNews&id=<?php echo $row['id'] ?>">|update</a>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
