<?php include "Templates/winter/partials/thongbao.php" ?>
<?php include "Templates/winter/partials/menu.php" ?>
<form action="index.php?controller=news&task=store" method="POST" >
    title:
    <input type="text" name="title" id="title" />
    <br />
    Content
    <input type="text" name="content" id="content" />
    <input type="submit" value="luu tin">
</form>
