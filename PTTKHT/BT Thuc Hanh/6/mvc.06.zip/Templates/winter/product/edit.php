<?php include "Templates/winter/partials/menu.php" ?>
edit form:
<form action="index.php?controller=product&task=save" method="POST" >
    title:
    <input type="text" name="title" id="title" value="<?php echo $row['title'] ?>" />
    <br />
    price
    <input type="text" name="price" id="price" value="<?php echo $row['price'] ?>" />
    <input type="hidden" name="id" value="<?php echo $row['id'] ?>" />
    <input type="submit" value="luu tin">
</form>
