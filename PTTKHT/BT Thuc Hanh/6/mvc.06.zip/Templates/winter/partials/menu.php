<ul>
    <li><a href="?controller=news&task=index">Xem Tin</a></li>
    <li><a href="?controller=news&task=create">Tao Tin moi</a></li>
</ul>

<ul>
    <li><a href="?controller=product&task=index">xem san pham</a></li>
    <li><a href="?controller=product&task=create">them san pham</a></li>
</ul>
