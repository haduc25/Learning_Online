<?php
if(isset($n)){
    if($n=="thanhcong") echo "success";
    if($n=="khongthanhcong") echo "fail";
}
