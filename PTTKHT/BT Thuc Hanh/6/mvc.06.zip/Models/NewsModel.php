<?php
require_once "Models/Model.php";

class NewsModel extends Model
{
    public function __construct()
    {
        parent::__construct();
    }

    public function getNews()
    {
        $sql = "SELECT * from news";
        $rs = $this->con->query($sql);
        $results = [];
        while ($row = $rs->fetch_assoc()) {
            $results[] = $row;
        }

        return $results;
    }

    public function storeNews($form)
    {
        $sql = "INSERT INTO news(title,content) VALUES('".$form['title']."','".$form['content']."')";
        $rs = $this->con->query($sql);
        if($rs != true){
            var_dump($this->con->error);exit;
        }
        return $rs;
    }

    public function deleteNews($id)
    {

        $sql ="DELETE FROM news WHERE id='".$id."'";
        return $this->con->query($sql);
    }

    public function getSingleNews($id)
    {
        $sql = "SELECT * from news WHERE id=".$id;
        $rs = $this->con->query($sql);
        return $rs->fetch_assoc();
    }

    public function saveNews(array $form)
    {
        $sql = "UPDATE news SET title = '".$form['title']."', content = '".$form['content']."'  WHERE id ='".$form['id']."'";
        //echo $sql; exit;
        return $this->con->query($sql);
        //var_dump($this->con->error);exit;
    }
}