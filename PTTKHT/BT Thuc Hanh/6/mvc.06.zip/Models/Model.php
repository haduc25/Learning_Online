<?php

class Model
{
    var $con;
    /**
     * Model constructor.
     */
    public function __construct()
    {
        $this->con = mysqli_connect("localhost", "root", "root", "news");
    }

}