<?php
require_once "Models\NewsModel.php";
require_once "Views\NewsView.php";

class NewsController
{
    var $model;
    var $view;

    /**
     * NewsController constructor.
     */
    public function __construct()
    {
        $this->model = new NewsModel();
        $this->view = new NewsView();
    }

    public function index()
    {
        $n = @$_REQUEST['n'];
        $results = $this->model->getNews();
        $this->view->indexNews($results,$n);
    }

    public function create()
    {
        $this->view->renderFormNews();
        
    }

    public function store()
    {
        $form = [];
        $form['title'] = $_REQUEST['title'];
        $form['content'] = $_REQUEST['content'];
        $rs = $this->model->storeNews($form);
        if($rs == true){
            header('Location: ?controller=news&task=index&n=thanhcong');
        }else{
            header('Location: ?controller=news&task=index&n=khongthanhcong');
        }
    }

    public function delete()
    {
        $id = $_REQUEST['id'];
        $rs = $this->model->deleteNews($id);
        if($rs == true){
            header('Location: ?task=getNews&n=thanhcong');
        }else{
            header('Location: ?task=getNews&n=khongthanhcong');
        }

    }

    public function update()
    {
        $id = $_REQUEST['id'];
        $row = $this->model->getSingleNews($id);
        $this->view->editForm($row);
        
    }
    public function save()
    {
        $form = [];
        $form['id'] = $_REQUEST['id'];
        $form['title'] = $_REQUEST['title'];
        $form['content'] = $_REQUEST['content'];
        $rs = $this->model->saveNews($form);
        //var_dump($rs);exit;
        if($rs == true){
            header('Location: ?task=getNews&n=thanhcong');
        }else{
            header('Location: ?task=getNews&n=khongthanhcong');
        }
    }
}