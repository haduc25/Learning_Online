<?php
require_once "VIews/View.php";
class NewsView extends View
{
    public function __construct()
    {
        parent::__construct();
    }

    public function indexNews($results,$n)
    {
        include "Templates/".$this->template."/news/index.php";
    }

    public function renderFormNews()
    {
        include "Templates/".$this->template."/news/create.php";
    }

    public function editForm(array $row)
    {
        include "Templates/".$this->template."/news/edit.php";
    }
}