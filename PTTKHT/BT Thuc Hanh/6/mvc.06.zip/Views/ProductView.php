<?php
require_once "VIews/View.php";

class ProductView extends View
{
    public function __construct()
    {
        parent::__construct();
    }

    public function index(array $data)
    {
        include "Templates/".$this->template."/product/index.php";
    }

    public function edit(array $row)
    {
        include "Templates/".$this->template."/product/edit.php";
    }
}