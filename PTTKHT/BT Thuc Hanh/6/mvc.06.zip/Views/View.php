<?php


class View
{
    var $template;

    /**
     * NewsView constructor.
     */
    public function __construct()
    {
        $this->template = "winter";
    }

}